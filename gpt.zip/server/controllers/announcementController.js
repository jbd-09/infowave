const Announcement = require("../models/Announcement");

console.log("Announcement =", Announcement);
console.log("typeof =", typeof Announcement);

// Create Announcement
const createAnnouncement = async (req, res) => {
  try {
    const announcement = await Announcement.create(req.body);

    res.status(201).json({
      success: true,
      message: "Announcement created successfully",
      data: announcement,
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

module.exports = {
  createAnnouncement,
};